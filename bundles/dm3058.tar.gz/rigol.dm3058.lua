-- Convenience macros for the Rigol DM3058 profile.
--
-- These are intentionally small: the engine already exposes every command in
-- dm3058.json. Lua is used only for sequences that need a query first, such as
-- reading the active function before choosing a measurement command.

local measure_commands = {
  DCV = ":MEASure:VOLTage:DC?",
  ACV = ":MEASure:VOLTage:AC?",
  DCI = ":MEASure:CURRent:DC?",
  ACI = ":MEASure:CURRent:AC?",
  RESISTANCE = ":MEASure:RESistance?",
  FRESISTANCE = ":MEASure:FRESistance?",
  FREQUENCY = ":MEASure:FREQuency?",
  PERIOD = ":MEASure:PERiod?",
  CONTINUITY = ":MEASure:CONTinuity?",
  DIODE = ":MEASure:DIODe?",
  CAPACITANCE = ":MEASure:CAPacitance?",
}

local function active_function()
  local raw = scpi.query(":FUNCtion?")
  return string.upper((string.gsub(raw, "%s+$", "")))
end

-- Read the value of the function currently shown on the primary display.
function measure()
  local function_name = active_function()
  local command = measure_commands[function_name]
  if not command then
    error("unsupported measurement function: " .. function_name)
  end
  local raw = scpi.query(command)
  local value = tonumber(raw)
  if value == nil then
    error("instrument returned a non-numeric measurement: " .. raw)
  end
  return value
end

-- Read one named function regardless of the current display mode.
function measure_function(function_name)
  local command = measure_commands[string.upper(function_name)]
  if not command then
    error("unsupported measurement function: " .. tostring(function_name))
  end
  local raw = scpi.query(command)
  local value = tonumber(raw)
  if value == nil then
    error("instrument returned a non-numeric measurement: " .. raw)
  end
  return value
end

-- Snapshot of identification plus the current reading.
function identify_and_measure()
  return scpi.idn() .. " => " .. tostring(measure())
end
